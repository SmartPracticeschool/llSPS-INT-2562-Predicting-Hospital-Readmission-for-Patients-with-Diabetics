
from flask import Flask , render_template , request
 # interfacee between by server and my application wsgi
import pickle

app =Flask(__name__,template_folder='templates')
model=pickle.load(open('readmission.pkl','rb'))
scaler=pickle.load(open('scaler.pkl','rb'))



@app.route('/')
def helloworld():
    return render_template("index2.html")
@app.route("/predict",methods=['POST'])
def main(): 
        p = request.form["n"]
        q = request.form["a"]
        s = request.form["t"]
        u = request.form["p"]
        m = request.form["nop"]
        v = request.form["m"]
        w = request.form["d"]
        x = request.form["c"]
        y = request.form["dm"]
        z = request.form["tv"]
        l = request.form["dc0"]
        a = request.form["dc1"]
        b = request.form["dc2"]
        c = request.form["dc3"]
        d = request.form["dc4"]
        e = request.form["dc5"]
        f = request.form["dc6"]
        g = request.form["dc7"]
        h = request.form["ar1"]
        i = request.form["ar2"]
        j = request.form["ar3"]
        k = request.form["tt"]
        n = request.form["at1"]
        o = request.form["at2"]
        aa =request.form["at3"]
        bb =request.form["at6"]
        cc =request.form["dd1"]
        dd =request.form["dd3"]
        ee =request.form["dd6"]
        ff =request.form["dd22"]
        gg=request.form["as1"]
        hh=request.form["as7"]
        gen =request.form["gen"]
        race =request.form["race"]
        if (gen == "Male"):
            gen1,gen2,gen3 = 1,0,0
        if (gen == "Female"):
            gen1,gen2,gen3 = 0,1,0
        if (gen == "Others"):
            gen1,gen2,gen3 = 0,0,1
        if (race == "AmericanAfrican"):
            race1,race2 = 1,0
        if (race == "Caucasian"):
            race1,race2 = 0,1
        if (j=="Yes"):
            ar31,ar32=1,0
        if (j=="No"):
            ar31,ar32=0,1
       
        if (j=="Yes"):
            ar21,ar22=1,0
        if (j=="No"):
            ar21,ar22=0,1
        
        if (j=="Yes"):
            ar11,ar12=1,0
        if (j=="No"):
            ar11,ar12=0,1
            
        if (j=="Yes"):
            dc71,dc72=1,0
        if (j=="No"):
            dc71,dc72=0,1
            
        if (j=="Yes"):
            dc61,dc62=1,0
        if (j=="No"):
            dc61,dc62=0,1
            
        if (j=="Yes"):
            dc51,dc52=1,0
        if (j=="No"):
            dc51,dc52=0,1
            
        if (j=="Yes"):
            dc41,dc42=1,0
        if (j=="No"):
            dc41,dc42=0,1
            
        if (j=="Yes"):
            dc31,dc32=1,0
        if (j=="No"):
            dc31,dc32=0,1
            
        if (j=="Yes"):
            dc21,dc22=1,0
        if (j=="No"):
            dc21,dc22=0,1
            
        if (j=="Yes"):
            dc11,dc12=1,0
        if (j=="No"):
            dc11,dc12=0,1
            
        if (j=="Yes"):
            dc01,dc02=1,0
        if (j=="No"):
            dc01,dc02=0,1
            
        if (j=="Yes"):
            as11,as12=1,0
        if (j=="No"):
            dc11,dc12=0,1
            
        if (j=="Yes"):
            as71,as72=1,0
        if (j=="No"):
            as71,as72=0,1
            
        if (j=="Yes"):
            dd221,dd222=1,0
        if (j=="No"):
            dd221,dd222=0,1
            
        if (j=="Yes"):
            dd61,dd62=1,0
        if (j=="No"):
            dd61,dd62=0,1
            
        if (j=="Yes"):
            dd31,dd32=1,0
        if (j=="No"):
            dd31,dd32=0,1
            
        if (j=="Yes"):
            dd11,dd12=1,0
        if (j=="No"):
            dd11,dd12=0,1
            
        if (j=="Yes"):
            at61,at62=1,0
        if (j=="No"):
            at61,at62=0,1
            
        if (j=="Yes"):
            at31,at32=1,0
        if (j=="No"):
            at31,at32=0,1
            
        if (j=="Yes"):
            at21,at22=1,0
        if (j=="No"):
            at21,at22=0,1
            
        if (j=="Yes"):
            at11,at12=1,0
        if (j=="No"):
            at11,at12=0,1
            
        if (j=="Yes"):
            at21,at22=1,0
        if (j=="No"):
            at21,at22=0,1
            
        if (j=="Yes"):
            dm1,dm2=1,0
        if (j=="No"):
            dm1,dm2=0,1
            
        if (j=="Yes"):
            c1,c2=1,0
        if (j=="No"):
            c1,c2=0,1
        
        t= [[gen1,race1,race2,int(q),int(s),int(u),int(m),int(v),int(w),int(c1),int(dm1),int(z),int(dc01),int(dc11),int(dc21),int(dc31),int(dc41),int(dc51),int(dc61),int(dc71),int(ar11),int(ar21),int(ar31),int(k),int(at11),int(at21),int(at31),int(at61),int(dd11),int(dd31),int(dd61),int(dd221),int(as11),int(as71)]]
        output = model.predict(t)
        if(output==0):
            result="No"
        if(output==1):
            result="Yes"
        return render_template("index2.html",output =str(result))

@app.route('/user') 
def user():
    return "hie user"

if __name__ == '__main__':
    app.run(debug = True)